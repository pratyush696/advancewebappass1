import '@fortawesome/fontawesome-free/css/all.min.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min'; // Import Bootstrap JavaScript
import { MDBCol, MDBContainer, MDBFooter, MDBIcon, MDBRow } from 'mdb-react-ui-kit';
import React from 'react';
import './Home.css';
import carouselImage3 from './images/Scotiabank.jpg'; // Replace with your image paths
import gicImage1 from './images/gic1.jpg'; // Add your GIC images
import gicImage3 from './images/gic3.jpg'; // Add your GIC images
import gicImage4 from './images/gic4.jpg';
import gicImage5 from './images/gic5.jpg';

import carouselImage2 from './images/people.jpg'; // Replace with your image paths

const Home = () => {
  return (
    <div>
      {/* Carousel Section */}
      <div className='container' id='carousel'>
        <div id="carouselExample" className="carousel slide">
          <div className="carousel-inner">
            <div className="carousel-item active">
              <img 
                src={carouselImage2} 
                className="d-block w-100" 
                alt="Slide 2" 
              />
            </div>
            <div className="carousel-item">
              <img 
                src={carouselImage3} 
                className="d-block w-100" 
                alt="Slide 3" 
              />
            </div>
          </div>
          <button 
            className="carousel-control-prev" 
            type="button" 
            data-bs-target="#carouselExample" 
            data-bs-slide="prev"
          >
            <span className="carousel-control-prev-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Previous</span>
          </button>
          <button 
            className="carousel-control-next" 
            type="button" 
            data-bs-target="#carouselExample" 
            data-bs-slide="next"
          >
            <span className="carousel-control-next-icon" aria-hidden="true"></span>
            <span className="visually-hidden">Next</span>
          </button>
        </div>
      </div>


      {/* Main Banner Section */}
      <section className="banner-section bg-danger text-white py-5">
        <div className="container text-center">
          <h1 className="display-4">Guaranteed Investment Certificates (GIC)</h1>
          <p className="lead">Purchase your GIC today!</p>
        </div>
      </section>

      {/* Featured GIC Rates */}
      <section className="gic-rates py-5">
        <div className="container text-center">
          <h2>Featured GIC Rates</h2>
          <div className="row">
            <div className="col-md-4">
              <div className="card">
                <img src={gicImage3} className="card-img-top" alt="GIC Rate 1" />
                <div className="card-body bg-danger text-white">
                  <h5>3.90%</h5>
                  <p>On a Non-Redeemable GIC</p>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card">
                <img src={gicImage4} className="card-img-top" alt="GIC Rate 2" />
                <div className="card-body bg-danger text-white">
                  <h5>4.25%</h5>
                  <p>On a Short-Term GIC</p>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card">
                <img src={gicImage1} className="card-img-top" alt="GIC Rate 3" />
                <div className="card-body bg-danger text-white">
                  <h5>5.00% - 6.00%</h5>
                  <p>On a Long-Term GIC</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Types of GIC */}
      <section className="gic-types py-5">
        <div className="container">
          <h2 className="text-center mb-4">Types of GIC</h2>
          <div className="row">
            <div className="col-md-3">
              <div className="card">
                <img src={gicImage5} className="card-img-top" alt="Non-Redeemable GIC" />
                <div className="card-body bg-danger text-white">
                  <h5>Non-Redeemable GICs</h5>
                  <p>Learn about Non-Redeemable GICs.</p>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="card">
                <img src={gicImage3} className="card-img-top" alt="Cashable GIC" />
                <div className="card-body bg-danger text-white">
                  <h5>Cashable GICs</h5>
                  <p>Learn about Cashable GICs.</p>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="card">
                <img src={gicImage4} className="card-img-top" alt="Market Linked GIC" />
                <div className="card-body bg-danger text-white">
                  <h5>Market Linked GICs</h5>
                  <p>Learn about Market Linked GICs.</p>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="card">
                <img src={gicImage1} className="card-img-top" alt="Personal Redeemable GIC" />
                <div className="card-body bg-danger text-white">
                  <h5>Personal Redeemable GICs</h5>
                  <p>Learn about Personal GICs.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer Section */}
      <MDBFooter bgColor='light' className='text-center text-lg-start text-muted'>
        <section className='d-flex justify-content-center justify-content-lg-between p-4 border-bottom'>
          <div className='me-5 d-none d-lg-block'>
            <span>Get connected with us on social networks:</span>
          </div>
          <div>
            <a href='' className='me-4 text-reset'>
              <MDBIcon color='secondary' fab icon='facebook-f' />
            </a>
            <a href='' className='me-4 text-reset'>
              <MDBIcon color='secondary' fab icon='twitter' />
            </a>
            <a href='' className='me-4 text-reset'>
              <MDBIcon color='secondary' fab icon='google' />
            </a>
            <a href='' className='me-4 text-reset'>
              <MDBIcon color='secondary' fab icon='instagram' />
            </a>
            <a href='' className='me-4 text-reset'>
              <MDBIcon color='secondary' fab icon='linkedin' />
            </a>
            <a href='' className='me-4 text-reset'>
              <MDBIcon color='secondary' fab icon='github' />
            </a>
          </div>
        </section>

        <section className=''>
          <MDBContainer className='text-center text-md-start mt-5'>
            <MDBRow className='mt-3'>
              <MDBCol md='3' lg='4' xl='3' className='mx-auto mb-4'>
                <h6 className='text-uppercase fw-bold mb-4'>
                  <MDBIcon color='secondary' icon='gem' className='me-3' />
                  Scotiabank
                </h6>
                <p>
                  Have a question? Don't hesitate to call us!!!!
                </p>
              </MDBCol>

              <MDBCol md='3' lg='4' xl='3' className='mx-auto mb-4'>
                <h6 className='text-uppercase fw-bold mb-4'>
                  <MDBIcon color='secondary' icon='info-circle' className='me-3' />
                  About Us
                </h6>
                <p>
                  Learn more about our services and values.
                </p>
              </MDBCol>

              <MDBCol md='3' lg='4' xl='3' className='mx-auto mb-4'>
                <h6 className='text-uppercase fw-bold mb-4'>
                  <MDBIcon color='secondary' icon='address-book' className='me-3' />
                  Contact
                </h6>
                <p>
                  1234 Street Name, City, State, Country
                </p>
                <p>
                  Email: info@scotiabank.com
                </p>
                <p>
                  Phone: (123) 456-7890
                </p>
              </MDBCol>

              <MDBCol md='3' lg='4' xl='3' className='mx-auto mb-4'>
                <h6 className='text-uppercase fw-bold mb-4'>
                  <MDBIcon color='secondary' icon='cogs' className='me-3' />
                  Services
                </h6>
                <p>
                  <a href="#!" className='text-reset'>GIC Options</a>
                </p>
                <p>
                  <a href="#!" className='text-reset'>Investment Planning</a>
                </p>
                <p>
                  <a href="#!" className='text-reset'>Customer Support</a>
                </p>
                <p>
                  <a href="#!" className='text-reset'>Online Banking</a>
                </p>
              </MDBCol>
            </MDBRow>
          </MDBContainer>
        </section>

        <section className='p-4'>
          <MDBContainer>
            <p className='text-center mb-0'>
              © 2024 Scotiabank. All rights reserved.
            </p>
          </MDBContainer>
        </section>
      </MDBFooter>
    </div>
  );
}

export default Home;
