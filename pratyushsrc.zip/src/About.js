import "bootstrap/dist/css/bootstrap.min.css";
import { Button, Card, Col, Container, Row } from 'react-bootstrap';


const About = () => {
  return (
    <div>
      {/* Hero Banner */}
      <div className="hero-banner text-center text-white bg-primary py-5">
        <Container>
          <h1 className="display-4">Welcome toBank of Nova Scotia Canada</h1>
          <p className="lead">Your trusted partner in financial success.</p>
        </Container>
      </div>

      {/* Main Content */}
      <Container className="mt-5">
        <Row>
          <Col md={4}>
            <Card>
              <Card.Img variant="top" src="https://via.placeholder.com/150" />
              <Card.Body>
                <Card.Title>Reliable Service</Card.Title>
                <Card.Text>
                  We provide reliable banking services that you can count on.
                </Card.Text>
                <Button variant="primary">Learn More</Button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card>
              <Card.Img variant="top" src="https://via.placeholder.com/150" />
              <Card.Body>
                <Card.Title>Transparency</Card.Title>
                <Card.Text>
                  Our services are transparent, ensuring you understand every detail.
                </Card.Text>
                <Button variant="primary">Learn More</Button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card>
              <Card.Img variant="top" src="https://via.placeholder.com/150" />
              <Card.Body>
                <Card.Title>Excellent Customer Service</Card.Title>
                <Card.Text>
                  Our customer service is top-notch, always ready to assist you.
                </Card.Text>
                <Button variant="primary">Learn More</Button>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        <div className="mt-5 text-center">
          <h2>Our Commitment</h2>
          <p className="lead">
            At Best Bank of Canada, we are committed to providing the highest level of service and support. Our team is dedicated to ensuring your financial needs are met with professionalism and care.
          </p>
        </div>
      </Container>
    </div>
  );
};

export default About;
