import "bootstrap/dist/css/bootstrap.min.css";
import React, { useState } from "react";

function BankingSystem() {
  const [accountNumber, setAccountNumber] = useState("");
  const [amount, setAmount] = useState("");
  const [transactions, setTransactions] = useState([]);
  const [balance, setBalance] = useState(0);
  const [isDeposit, setIsDeposit] = useState(true);

  const handleDeposit = () => {
    const amt = parseFloat(amount);
    if (!isNaN(amt) && amt > 0) {
      setBalance(balance + amt);
      const newTransaction = {
        accountNumber,
        amount: amt,
        type: "Deposit",
        balanceAfter: balance + amt,
      };
      setTransactions([...transactions, newTransaction]);
      setAmount("");
      setAccountNumber("");
    }
  };

  const handleWithdraw = () => {
    const amt = parseFloat(amount);
    if (!isNaN(amt) && amt > 0 && amt <= balance) {
      setBalance(balance - amt);
      const newTransaction = {
        accountNumber,
        amount: amt,
        type: "Withdraw",
        balanceAfter: balance - amt,
      };
      setTransactions([...transactions, newTransaction]);
      setAmount("");
      setAccountNumber("");
    }
  };

  return (
    <div className="container">
      <h1 className="text-center mt-5 mb-4">Transaction System</h1>
      <div className="d-flex justify-content-center mb-4">
        <button
          className={`btn ${isDeposit ? "btn-primary" : "btn-secondary"} mx-2`}
          onClick={() => setIsDeposit(true)}
        >
          Deposit
        </button>
        <button
          className={`btn ${isDeposit ? "btn-secondary" : "btn-danger"} mx-2`}
          onClick={() => setIsDeposit(false)}
        >
          Withdraw
        </button>
      </div>

      <div className="card p-4 shadow-lg mb-4">
        <h2>{isDeposit ? "Deposit" : "Withdraw"}</h2>
        <input
          type="text"
          className="form-control my-2"
          placeholder="Account Number"
          value={accountNumber}
          onChange={(e) => setAccountNumber(e.target.value)}
        />
        <input
          type="number"
          className="form-control my-2"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <div className="d-flex justify-content-between mt-3">
          <button
            className={`btn ${isDeposit ? "btn-success" : "btn-warning"} mx-2`}
            onClick={isDeposit ? handleDeposit : handleWithdraw}
          >
            {isDeposit ? "Deposit" : "Withdraw"}
          </button>
          <button
            className="btn btn-secondary mx-2"
            onClick={() => {
              setAccountNumber("");
              setAmount("");
            }}
          >
            Cancel
          </button>
        </div>
      </div>

      <h2 className="mt-5 mb-4">Transaction History</h2>
      <table className="table table-striped table-bordered">
        <thead>
          <tr>
            <th>Account Number</th>
            <th>Amount</th>
            <th>Type</th>
            <th>Balance After Transaction</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map((transaction, index) => (
            <tr key={index}>
              <td>{transaction.accountNumber}</td>
              <td>${transaction.amount.toFixed(2)}</td>
              <td>{transaction.type}</td>
              <td>${transaction.balanceAfter.toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default BankingSystem;
